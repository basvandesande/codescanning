namespace MyConsoleApp
{
    public class Program
    {
        // force warning in codeQL
        public static void Main(string[] args)
        {
            Console.Write("Hello World");
            Console.Write("This is a test");
            Console.ReadKey();
        }
    }
}